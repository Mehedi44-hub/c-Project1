﻿Public Class Form1
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        LabelHelloWorld.Text = "Hello World"
    End Sub

    Private Sub ButtonHelloWorld_Click(sender As Object, e As EventArgs) Handles ButtonHelloWorld.Click

    End Sub
End Class
